# Guía Paso a Paso: Cómo activar tu Lista de Tareas sincronizada (Gratis)

Sigue estos 5 pasos una sola vez (te tomará unos 6 a 8 minutos). No necesitas tarjeta de crédito ni instalar nada en tu computadora.

---

## PASO 1: Crear tu proyecto gratuito en Firebase
1. Entra a **[https://console.firebase.google.com/](https://console.firebase.google.com/)** e inicia sesión con tu cuenta de Google.
2. Haz clic en **"Crear un proyecto"** (o *"Agregar proyecto"*).
3. Ponle un nombre (por ejemplo: `mis-tareas`) y dale a **Continuar**.
4. Desactiva Google Analytics (no lo necesitas y así es más rápido) y haz clic en **Crear proyecto**. Espera unos segundos y pulsa **Continuar**.

---

## PASO 2: Activar el Inicio de Sesión (Authentication)
1. En el menú izquierdo, entra en **Compilación (Build) → Authentication** y pulsa **Comenzar**.
2. En la pestaña **Método de acceso (Sign-in method)**:
   - Haz clic en **Google** → activa el interruptor **"Habilitar"** → elige tu correo de soporte → pulsa **Guardar**.
   - *(Opcional pero muy útil)* Haz clic en **Agregar proveedor nuevo** → **Correo electrónico/contraseña** → activa el primer interruptor **"Correo electrónico/contraseña"** → pulsa **Guardar**.
3. Ve a la pestaña **Configuración (Settings)** (ahí mismo dentro de Authentication) → busca **Dominios autorizados** → haz clic en **Agregar dominio** y escribe el dominio de tu GitHub Pages (solo el dominio, sin `https://` ni rutas):
   - Ejemplo: `tu-usuario.github.io`

---

## PASO 3: Crear la Base de Datos (Firestore Database) y poner su candado
1. En el menú izquierdo, entra en **Compilación (Build) → Firestore Database** y pulsa **Crear base de datos**.
2. Deja la ubicación que te sugiere (ej. `nam5 (us-central)`) y dale a **Siguiente**.
3. Elige **Comenzar en modo de producción** y haz clic en **Crear**.
4. Una vez creada, haz clic arriba en la pestaña **Reglas (Rules)**.
5. Borra todo lo que aparece ahí, pega exactamente este código (también viene en el archivo `firestore.rules`) y pulsa **Publicar**:

```javascript
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    match /usuarios/{userId}/tareas/{tareaId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```
*(Esto garantiza que nadie más en internet pueda ver ni modificar tus tareas; solo tu cuenta).*

---

## PASO 4: Copiar tus llaves de conexión (`firebaseConfig`)
1. Arriba a la izquierda, junto a *"Descripción general del proyecto"*, haz clic en el **ícono de engrane ⚙️ → Configuración del proyecto**.
2. Baja hasta la sección **"Tus apps"** y haz clic en el botón web **`</>`**.
3. Ponle un apodo (ej. `Web GitHub`), **NO** marques Firebase Hosting, y pulsa **Registrar app**.
4. Te aparecerá un bloque de código que dice `const firebaseConfig = { ... };`.
5. **Conéctalo de cualquiera de estas dos maneras:**
   - **Forma A (Recomendada para que funcione directo en todos tus aparatos):** Abre el archivo `firebase-config.js` (en el bloc de notas o directamente editándolo en GitHub) y reemplaza los textos `"PEGA_AQUI..."` con los valores de tu `firebaseConfig`.
   - **Forma B (Cero edición de archivos):** Sube los archivos tal cual están, y cuando abras tu página haz clic en el botón **"⚙️ Conectar mi base de datos Firebase"** y pega ahí el bloque completo.

---

## PASO 5: Subir los archivos a tu repositorio de GitHub
1. Descomprime el archivo `.zip`.
2. Entra a tu repositorio en **GitHub.com**.
3. Haz clic en **Add file → Upload files**.
4. Arrastra todos los archivos (`index.html`, `style.css`, `script.js`, `firebase-config.js`, `sw.js`, `manifest.json`, etc.).
   *(Nota: Si ya tienes tu propia carpeta `icons/` en tu repositorio, puedes conservar la tuya o subir la incluida en el `.zip`).*
5. Abajo haz clic en el botón verde **Commit changes**.
6. Espera ~1 minuto a que GitHub Pages actualice, abre tu enlace en tu **compu** y en tu **celular** (si ya la tenías abierta antes, recárgala una vez), inicia sesión con **la misma cuenta**, ¡y verás cómo lo que escribes o tachas en uno aparece al instante en el otro!
